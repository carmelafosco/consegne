<?php
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'sitedeorod' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', '' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'LtC[8sdjM~OcXS_WPO}Ilw7>@cKUk7GpB63]XmyuJ[]tYb;grjQvv #uo=0-irV:' );
define( 'SECURE_AUTH_KEY',  '@@f8!pi2Y$5CY2k<(N9bYZZ6H%v!=z[tCF!FpHuO7srIrGZwV.s73jPf~=`q&^,r' );
define( 'LOGGED_IN_KEY',    'Rpy`QyNX956d}Yw[.f?{MCgN*9(THy-Ei(1G]*I7gXE+lBkY;FfZDit,lzD]|:T$' );
define( 'NONCE_KEY',        'ZjQ[J7@bls>Gx`|b$##c;KT9r_qnJkwp|N[AY{ u.{ZyJ[B.)`){!3{}w1bS2gQr' );
define( 'AUTH_SALT',        'GV@YaD[;F=<|+=P)P. vKHC+/Y_(7R!8So|LA(.,cx{kUGoD]/e=e14<v1;nCp.C' );
define( 'SECURE_AUTH_SALT', 'fZ,5S8}6?kag+p3<x6H/q/T(#$&Gh;R`wrbWA5#Y`T60<Vg^b47XdE1<bH9dQ<|v' );
define( 'LOGGED_IN_SALT',   'NK%@A>$zFg/(ZlZ*_c(>/%A:Z`08s/0u+QNS{@?(J9WR(xUa9?SFb~wo:;!p-g*/' );
define( 'NONCE_SALT',       '~N-A3iG:!ImwP>b(nxK$>WfU-8PsK@|!E3qlq_-oUdzUZV,4z#LP&A#>Hf_IM9%I' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'wp_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';
